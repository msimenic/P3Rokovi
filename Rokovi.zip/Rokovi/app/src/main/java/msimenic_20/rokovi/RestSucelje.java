package msimenic_20.rokovi;

import msimenic_20.rokovi.model.Odgovor;

public interface RestSucelje {

    public void zavrseno(Odgovor odgovor);

}
